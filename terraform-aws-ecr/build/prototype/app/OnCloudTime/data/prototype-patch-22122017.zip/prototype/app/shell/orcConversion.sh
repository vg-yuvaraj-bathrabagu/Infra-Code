#!/bin/bash
AWS_ACCESS_KEY_ID=$3 AWS_SECRET_ACCESS_KEY=$4 aws s3 cp $1 $2
echo 0
